## Mentee Matcher

### Quick Start

Make sure that you have Node.js installed first.

```bash
node index.js
```

This program reads matchings from `in.txt` and outputs the matchings to `out.txt`.

(c) 2018 Sam Olagun
